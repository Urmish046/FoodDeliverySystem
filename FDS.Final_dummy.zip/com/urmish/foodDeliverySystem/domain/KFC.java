package com.urmish.foodDeliverySystem.domain;

public class KFC extends Restaurant {

    public KFC(String name, String location, Menu menu) {
        super(name, location, menu);
    }

    public KFC(){

    };
}
