package com.urmish.foodDeliverySystem.domain;

import java.util.Scanner;

public class Customer extends Person{
   private static final Scanner scanner = new Scanner(System.in);

    DeliveryBoy deliveryBoy;
    long phoneNumber;
    Address customerAddress;

    public Customer(String name, long phoneNumber, Address address) {
        super(name);
        this.phoneNumber = phoneNumber;
        this.customerAddress = address;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Address getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(Address customerAddress) {
        this.customerAddress = customerAddress;
    }

    public static Address inputAddress(){

        System.out.println("City: ");
        var city = scanner.nextLine();
        System.out.println("Area: ");
        var area = scanner.nextLine();
        System.out.println("Street number: ");
        var streetNumber = scanner.nextInt();
        System.out.println("House Number: ");
        var houseNumber = scanner.nextInt();

        Address myAddress = new Address(city,area,streetNumber,houseNumber);
        return myAddress;
    }

    public double calculateTime(DeliveryBoy deliveryBoy) {

        System.out.println("Enter the exact distance:");
        double distance = scanner.nextDouble();
        double time = 0;
            time = distance / deliveryBoy.speed;
        return time;
    }


    @Override
    public String toString() {
        return
                " customerAddress= " + customerAddress;

    }
}

