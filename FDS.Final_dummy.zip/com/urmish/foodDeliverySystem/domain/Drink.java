package com.urmish.foodDeliverySystem.domain;

public class Drink extends MenuItem {

    public Drink(String name, String description, int price) {
        super(name, description, price);
    }
}
