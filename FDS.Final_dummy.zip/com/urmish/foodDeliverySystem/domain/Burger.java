package com.urmish.foodDeliverySystem.domain;

public class Burger extends MenuItem {

    public Burger(String name, String description, int price) {
        super(name, description, price);
    }
}
