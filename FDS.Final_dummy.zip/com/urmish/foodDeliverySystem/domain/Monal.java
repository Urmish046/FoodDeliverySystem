package com.urmish.foodDeliverySystem.domain;

public class Monal extends Restaurant{

    public Monal(String name, String location, Menu menu) {
        super(name, location, menu);
    }


}
