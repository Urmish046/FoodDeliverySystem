package com.urmish.foodDeliverySystem;

import com.urmish.foodDeliverySystem.domain.*;
import com.urmish.foodDeliverySystem.repository.Cart;
import com.urmish.foodDeliverySystem.repository.DeliveryBoyFactory;
import com.urmish.foodDeliverySystem.repository.RestaurantFactoryForKFC;
import com.urmish.foodDeliverySystem.repository.RestaurantFactoryForMonal;

import java.util.Scanner;

import static com.urmish.foodDeliverySystem.domain.Customer.inputAddress;

public class FoodDeliverySys {

    private static final Scanner scanner = new Scanner(System.in);
    static RestaurantFactoryForKFC restaurantFactoryForKFC = new RestaurantFactoryForKFC();
    static RestaurantFactoryForMonal restaurantFactoryForMonal = new RestaurantFactoryForMonal();
    static Cart cart = new Cart();
    static DeliveryBoy[] deliveryBoy = DeliveryBoyFactory.getAllDeliveryBoys();

    public static void main(String[] args) {

        System.out.println("\nWelcome to Food Delivery System");
        System.out.println("====================================");

        System.out.println("Enter your Identity - Customer/Admin");
        var identity = scanner.nextLine();

        if (identity.equalsIgnoreCase("Admin")){
            System.out.println(":: System Details ::");
            System.out.println("--List of restaurants:        1.KFC    2.Monal");
            System.out.println("--List of Delivery Boys: ");
            for (DeliveryBoy db : deliveryBoy){
                System.out.println("Name:"+db.getName()+"\nPhoneNumber:"+db.getPhoneNumber()+"\nID"+db.getId());
                System.out.println();
            }
        } else if (identity.equalsIgnoreCase("customer")){

            System.out.println("Enter your name: ");
            var name = scanner.nextLine();
            System.out.println("Enter you phone number: ");
            var pn = scanner.nextInt();
            System.out.println("Enter your Address Details Please.");

            Customer customer = new Customer(name,pn,inputAddress());

            scanner.nextLine();
            System.out.println("Enter you desired Restaurant:");
            var rest = scanner.nextLine();

            if (rest.equalsIgnoreCase("kfc")) {
                System.out.println("       :: KFC ::");
                System.out.println("=========================");

                KFC kfc = restaurantFactoryForKFC.createKfcRestaurant("kamra");

                Menu menu = kfc.getMenu();
                menu.displayCategories();

                System.out.println();
                System.out.println("Choose your category:");
                var cat = scanner.nextLine();
                var category = kfc.getCategoryItemByName(cat);

                System.out.println("Choose your item from the above categories:");
                var item = scanner.nextLine();
                var myItem = kfc.getMenuItemByName(category,item);

                System.out.println("Enter the quantity for your items:");
                var quantity = scanner.nextInt();

                for (int i = 0; i < quantity; i++) {
                    cart.addToCart(myItem);
                }

                scanner.nextLine();
                System.out.println("Want to remove an item?");
                var removeItem = scanner.nextLine();
                if (removeItem.equalsIgnoreCase("Yes")){
                        cart.subtractFromCart(myItem);
                }

                System.out.println("Do you want to apply voucher - yes/no?");
                var ans = scanner.nextLine();
                if (ans.equalsIgnoreCase("yes")){
                    System.out.println("Enter the code: ");
                    var code = scanner.nextLine();
                    cart.applyVoucher(code);
                }


                System.out.println("\n:: Order Details ::");
                System.out.println("---------------------------");
                System.out.println("Name: "+customer.getName()+"  \nPhone Number: "+customer.getPhoneNumber());
                System.out.println("Your Order is: \n"+quantity+" "+myItem+ "of " + category+"category.");
                System.out.println("Total: "+cart.getCartTotal()+".");
                System.out.println("(Your order will be delivered to customerAddress: "+customer.getCustomerAddress());
                DeliveryBoy deliveryBoy1 = deliveryBoy[0];
                System.out.println("Delivery Boy: "+deliveryBoy1.getName()+" (ID-"+deliveryBoy1.getId()+")"+ " Phone Number: "+deliveryBoy1.getPhoneNumber());
                System.out.println(customer.calculateTime(deliveryBoy1)+" seconds.");

//---------------------------------------------------------------------------------------------------------------------

            } else if (rest.equalsIgnoreCase("monal")) {
                    System.out.println("       :: Monal ::");
                    System.out.println("=========================");

                    Monal monal = restaurantFactoryForMonal.createMonalRestaurant("kamra");

                    Menu menu = monal.getMenu();
                    menu.displayCategories();

                    System.out.println();
                    System.out.println("Choose your category:");
                    var cat = scanner.nextLine();
                    var category = monal.getCategoryItemByName(cat);

                    System.out.println("Choose your item from the above categories:");
                    var item = scanner.nextLine();
                    var myItem = monal.getMenuItemByName(category,item);

                    System.out.println("Enter the quantity for your items:");
                    var quantity = scanner.nextInt();

                    for (int i = 0; i < quantity; i++) {
                        cart.addToCart(myItem);
                    }

                    scanner.nextLine();
                    System.out.println("Want to remove an item?");
                    var removeItem = scanner.nextLine();
                    if (removeItem.equalsIgnoreCase("Yes")){
                        cart.subtractFromCart(myItem);
                    }

                    System.out.println("Do you want to apply voucher - yes/no?");
                    var ans = scanner.nextLine();
                    if (ans.equalsIgnoreCase("yes")){
                        System.out.println("Enter the code: ");
                        var code = scanner.nextLine();
                        cart.applyVoucher(code);
                    }

                    System.out.println("\n:: Order Details ::");
                    System.out.println("---------------------------");
                    System.out.println("Name: "+customer.getName()+"  \nPhone Number: "+customer.getPhoneNumber());
                    System.out.println("Your Order is: \n"+quantity+" "+myItem+ "of " + category+"category.");
                    System.out.println("Total: "+cart.getCartTotal()+".");
                    System.out.println("(Your order will be delivered to customerAddress: "+customer.getCustomerAddress());
                    DeliveryBoy deliveryBoy2 = deliveryBoy[2];
                    System.out.println("Delivery Boy: "+deliveryBoy2.getName()+" (ID-"+deliveryBoy2.getId()+")"+ " Phone Number: "+deliveryBoy2.getPhoneNumber());
                System.out.println(customer.calculateTime(deliveryBoy2)+" seconds.");

            }

        }







        }
    }

